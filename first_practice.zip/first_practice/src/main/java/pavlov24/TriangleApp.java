package pavlov24;

import java.util.Scanner;

public class TriangleApp {

    public static void main(String[] args) {
        final double EPS = 0.000001;
        double x1, y1, x2, y2, x3, y3;
        // 1. Чтение данных
        Scanner scanner = new Scanner(System.in);
        System.out.print("Введите координаты вершины A: ");
        x1 = scanner.nextDouble();
        y1 = scanner.nextDouble();
        System.out.print("Введите координаты вершины B: ");
        x2 = scanner.nextDouble();
        y2 = scanner.nextDouble();
        System.out.print("Введите координаты вершины C: ");
        x3 = scanner.nextDouble();
        y3 = scanner.nextDouble();
        // 2. Проверка входных значений
        if ((Math.abs(x1 - x2) < EPS) && (Math.abs(y1-y2) < EPS)) {
            System.out.println("Ошибка! Точка А не должна совпадать с точкой B.");
            return; // досрочный выход
        }
        if ((Math.abs(x2 - x3) < EPS) && (Math.abs(y2-y3) < EPS)) {
            System.out.println("Ошибка! Точка B не должна совпадать с точкой C.");
            return; // досрочный выход
        }
        if ((Math.abs(x1 - x3) < EPS) && (Math.abs(y1-y3) < EPS)) {
            System.out.println("Ошибка! Точка A не должна совпадать с точкой C.");
            return; // досрочный выход
        }
        if ((Math.abs(x1 - x2) < EPS) && (Math.abs(x2-x3) < EPS)) {
            System.out.println("Ошибка! Точки А, B и С не должны лежать на одной прямой по оси X");
            return; // досрочный выход
        }
        if ((Math.abs(y1 - y2) < EPS) && (Math.abs(y2-y3) < EPS)) {
            System.out.println("Ошибка! Точки А, B и С не должны лежать на одной прямой по оси Y");
            return; // досрочный выход
        }
        double left = (x3 - x1) / (x2 - x1);
        double right = (y3 - y1) / (y2 - y1);
        if ((Math.abs(left - right) < EPS)) {
            System.out.println("Ошибка! Точки А, B и С не должны лежать на одной прямой");
            return; // досрочный выход
        }


        // 3. Вычисление длин сторон треугольника
        double a, b, c;
        a = Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
        b = Math.sqrt(Math.pow(x3 - x2, 2) + Math.pow(y3 - y2, 2));
        c = Math.sqrt(Math.pow(x3 - x1, 2) + Math.pow(y3 - y1, 2));
        System.out.printf("Длина стороны АB = %.2f\n", a);
        System.out.printf("Длина стороны BC = %.2f\n", b);
        System.out.printf("Длина стороны АC = %.2f\n", c);
        // 4. Вычисление углов между сторонами треугольника
        double alpha, beta, gamma;
        alpha = Math.toDegrees(Math.acos(-(a * a - b * b - c * c)/(2*b*c)));
        beta = Math.toDegrees(Math.acos(-(b * b - a * a - c * c)/(2*a*c)));
        gamma = Math.toDegrees(Math.acos(-(c * c - b * b - a * a)/(2*b*a)));
        System.out.printf("Угол между сторонами АB и AC = %.2f\n", alpha);
        System.out.printf("Угол между сторонами АB и BC = %.2f\n", beta);
        System.out.printf("Угол между сторонами АC и BC = %.2f\n", gamma);

        double sum = alpha + beta + gamma;
        if (Math.abs(sum - 180.0) < EPS) {
            System.out.println("Сумма углов треугольника 180 градусов.");
        }

    }


}
