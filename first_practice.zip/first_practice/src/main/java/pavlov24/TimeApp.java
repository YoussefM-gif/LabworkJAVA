package pavlov24;

public class TimeApp {

    public static void main(String[] args) {

        int integer;
        // 01.01.1970

        long now = System.currentTimeMillis();
        long seconds = now / 1000;
        long currentSeconds = seconds % 60;

        long minutes = seconds / 60;
        long currentMinutes = minutes % 60;

        long hours = minutes / 60;
        long currentHours = hours % 24;

        long days = hours / 24;
        long months = days / 30;
        long years = months / 12;

        System.out.println("Текущее время в мс: " + now);
        System.out.println("Текущее время в сек: " + seconds);
        System.out.println("Текущее время в минутах: " + minutes);
        System.out.println("Текущее время в часах: " + hours);
        System.out.println("Текущее время в дни: " + days);
        System.out.println("Текущее время в месяцах: " + months);
        System.out.println("Текущее время в годах: " + years);
        System.out.println("Текущее время: " + currentHours + ":" + currentMinutes + ":" + currentSeconds);

    }


}
