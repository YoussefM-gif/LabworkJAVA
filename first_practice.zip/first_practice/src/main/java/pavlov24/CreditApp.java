package pavlov24;

import java.util.Scanner;

public class CreditApp {

    public static void main(String[] args) {
        double loan; // сумма займа (А)
        double yearRate; // ежегодная процентная ставка (i)
        int years; // срок (n)

        Scanner scanner = new Scanner(System.in);
        System.out.println("====================================");
        System.out.print("Сумма займа: ");
        loan = scanner.nextDouble();
        System.out.print("Процентная ставка: ");
        yearRate = scanner.nextDouble();
        System.out.print("Срок: ");
        years = scanner.nextInt();

        double monthlyRate = yearRate / 12 / 100;
        double monthlyPayment = (loan * monthlyRate) / (1 - ( 1 / Math.pow(1 + monthlyRate, years * 12)));

        System.out.println("Ежемесячный платеж по кредиту: " + monthlyPayment);

        double costCredit = monthlyPayment * years * 12;
        System.out.println("Стоимость кредита: " + costCredit);
        System.out.println("Переплата: " + (costCredit - loan));

        System.out.println("====================================");
        System.out.println("Хорошо подумай, прежде чем брать!");

    }

}
